<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();?>
<?
function buildList($section, $col_md_4 = false) {
  if (!isset($section["CHILD"]) && !isset($section["ITEMS"]) && !empty($section['ITEMS'])){?>
    <ul class="not_isset_child_and_not_isset_items">
      <?foreach($section["ITEMS"] as $item_id => $arItem){?>
        <li><a href="<?=$arItem["DETAIL_PAGE_URL"]?>"><?=$arItem["NAME"]?></a></li>
      <?}?>
    </ul>
  <?}
  // if(!empty($section["CHILD"])){?>
    <ul class="row sm_row">
            <?if(!empty($section['NAME'])){?>
                <li><a href="<?=$section['SECTION_PAGE_URL']?>"><?=$section['NAME']?></a></li>
            <?}?>
      <?foreach($section["CHILD"] as $child_id => $arChild){
        buildList($arChild);
      }?>
    </ul>
  <?//}
  if(!empty($section["ITEMS"])){?>
    <ul class="not_empty_items">
      <?foreach($section["ITEMS"] as $item_id => $arItem){?>
        <li><a href="<?=$arItem["DETAIL_PAGE_URL"]?>"><?=htmlspecialchars_decode($arItem["NAME"])?></a></li>
      <?}?>
    </ul>
  <?}
}
?>
<ul class="sitemap_html">
  <li><a href="/">Главная</a></li>
  <? $i1 = 0;

  $param = array();
  foreach ($arResult['FOLDERS'] as $k => $v) {
    $param[$k] = $v['PATH'];
  }
  array_multisort($param, SORT_ASC, SORT_STRING, $arResult['FOLDERS']);

  $arResult["FOLDERS"][] = array();
  foreach($arResult["FOLDERS"] as $root => $arFolder){
    $arFolder["count"] = count(explode('/', trim($arFolder["PATH"], '/')));
    // Начинать со второго индекса, смещение
    if ($i1 > 0) { ?>
      <li><a href="<?=$arrPrev["PATH"];?>"><?=$arrPrev["NAME"];?></a>

      <? // Еcли это папка с компонентом инфоблока, то вывести категории этого инфоблока
      $filePath = $_SERVER['DOCUMENT_ROOT'].$arrPrev["PATH"].'index.php';
      if (file_exists($filePath)) {
        $fp = fopen($filePath, 'r');
        $filesize = (int)filesize($filePath);
        if ($fp && $filesize) {
          $text = fread($fp, $filesize);
          // Вытянуть IBLOCK_ID
          preg_match('#IncludeComponent\s*\(\s*"bitrix:(?:(?:catalog(?:\.section)?)|(?:news))".+?"IBLOCK_ID" => "(\d+)",#is', $text, $match);

          if (isset($match[1]) && $match[1]) {
            if (isset($arResult["IBLOCKS"][$match[1]])) {
              //echo '<ul class="row">';
              foreach($arResult["IBLOCKS"][$match[1]] as $sect_id => $arSection) {
                //print_r($arSection);
                //if($sect_id !== 0)
                buildList($arSection);
              }
              //echo '</ul>';

              // Удалить, чтоб это же не выводилось в основном обходе инфоблоков, что ниже
              unset($arResult["IBLOCKS"][$match[1]]);
            }
          }
        }
        fclose($fp);
      }

      // теги для формирования нужной структуры
      if ($arrPrev["count"] < $arFolder["count"]) {
        echo '<ul>';
      } elseif ($arrPrev["count"] > $arFolder["count"])  {
        echo '</li></ul></li>';
      } else {
        echo '</li>';
      }
    }
    $arrPrev = $arFolder;
    $i1++;
  }

  // Инфоблоки, которые остались
  foreach($arResult["IBLOCKS"] as $ib_id => $arIblock){

    if(!empty($arIblock["ITEMS"])) {
      foreach($arIblock["ITEMS"] as $arItem) { ?>
        <li><a href="<?=$arItem["DETAIL_PAGE_URL"];?>"><?=$arItem["NAME"];?></a></li>
      <? }
    } else {
        $first_key = array_keys($arIblock)[0];
        $IBLOCK_ID = $arIblock[$first_key]['IBLOCK_ID'];
            $arIBlockData = GetIBlock($IBLOCK_ID);

            $mystring = mb_strtolower($arIBlockData['NAME']);
            $findme   = 'каталог';
            $pos = strpos($mystring, $findme);

            if ($pos === false) {?>
                <li><a href="<?=$arIBlockData["LIST_PAGE_URL"];?>"><?=$arIBlockData["NAME"];?></a></li>
            <?} else {?>
                <li><a href="<?=$arIBlockData["LIST_PAGE_URL"];?>">Каталог</a></li>
            <?}

      foreach($arIblock as $sect_id => $arSection) {
          if(!empty($arSection['NAME'])){
                    buildList($arSection);
                }
      }
    }
  }
  ?>
</ul>
