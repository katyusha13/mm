<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = array(
	"NAME" => "HTML карта сайта",
	"DESCRIPTION" => "Выводит html карту сайта",
	"ICON" => "/images/icon.gif",
	"CACHE_PATH" => "Y",
	"PATH" => array(
		"ID" => "Alittlebit.ru"
	),
);

?>