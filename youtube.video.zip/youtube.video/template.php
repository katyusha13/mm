<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
$this->setFrameMode(true);
?>
<?if(count($arResult["ITEMS"])>0){?>
    <?php if ($arParams['Title'] !== 'N'): ?>
    <h2 class="g-title">Видео</h2>
    <?php endif; ?>

    <div class="b-video g-table">
        <?php foreach ($arResult["ITEMS"] as $arItem): ?>
            <?php
            $this->AddEditAction($arItem['ID'], $arItem['EDIT_LINK'], CIBlock::GetArrayByID($arItem["IBLOCK_ID"], "ELEMENT_EDIT"));
            $this->AddDeleteAction($arItem['ID'], $arItem['DELETE_LINK'], CIBlock::GetArrayByID($arItem["IBLOCK_ID"], "ELEMENT_DELETE"), array("CONFIRM" => GetMessage('CT_BNL_ELEMENT_DELETE_CONFIRM')));
            $ExSrc=explode('src="',str_replace("<iframe" ,"",$arItem['PREVIEW_TEXT']));
            $ExSrc=explode('"',$ExSrc[1]);
            $url=strtr($ExSrc[0],['/embed/'=>'/watch?v='])."?autoplay=0";
            $videoID = end(explode('/', $ExSrc[0]));

            $arItem['PREVIEW_TEXT']=str_replace($ExSrc[0],$ExSrc[0]."?autoplay=0",$arItem['PREVIEW_TEXT']);
            $Src=str_replace("https://www.youtube.com/embed/","https://i.ytimg.com/vi/",$ExSrc[0])."/hqdefault.jpg";
            $dateEx=explode(" ",$arItem["DATE_CREATE"]);
            if(!isset($arItem["FIELDS"]["SHOW_COUNTER"]))$arItem["FIELDS"]["SHOW_COUNTER"]=0;
            ?>
        <div class="video-col">
            <div class="video-col">
                <div class="video youtube" data-preview-pic="<?=$arItem['PREVIEW_PICTURE']['SRC']?>" id="<?=$videoID?>"></div>
                <div class="video__info">
                    <div class="video__info-name"><a><?=$arItem['NAME']?></a></div>
                    <div class="video__info-date"><?=$dateEx[0]?> | <?=$arItem["FIELDS"]["SHOW_COUNTER"]?> <?=getCountEndWord($arItem["FIELDS"]["SHOW_COUNTER"], 'просмотр','просмотра','просмотров');?></div>
                </div>
            </div>
        </div>


        <?php endforeach ?>
    </div>

    <?if($arParams['Title']!="N"){?>
        <div class="g-look">
            <a class="g-look-link" href="/video/">Смотреть все <img src="<?=SITE_TEMPLATE_PATH?>/old/img/general/look-arrow.png" alt=""></a>
        </div>
    <?}?>
<?}?>
<script>
    setTimeout(youtubeVideoOpt, 1000);
</script>
